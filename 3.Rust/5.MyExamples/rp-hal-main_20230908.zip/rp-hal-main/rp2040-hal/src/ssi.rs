//! Synchronous Serial Interface (SSI)
// See [Chapter 4 Section 10](https://datasheets.raspberrypi.org/rp2040/rp2040_datasheet.pdf) for more details
// TODO
