//! Prelude
pub use crate::clocks::Clock as _rphal_clocks_Clock;
pub use crate::pio::PIOExt as _rphal_pio_PIOExt;
