# WiFi firmware

Firmware obtained from https://github.com/Infineon/wifi-host-driver/tree/master/WiFi_Host_Driver/resources/firmware/COMPONENT_43439

Licensed under the [Infineon Permissive Binary License](./LICENSE-permissive-binary-license-1.0.txt)