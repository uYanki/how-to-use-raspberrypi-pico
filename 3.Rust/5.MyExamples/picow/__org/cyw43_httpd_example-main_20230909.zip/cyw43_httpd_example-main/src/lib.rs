#![no_std]
#![feature(type_alias_impl_trait)]
#![feature(async_fn_in_trait, impl_trait_projections)]

pub mod pio_spi;

