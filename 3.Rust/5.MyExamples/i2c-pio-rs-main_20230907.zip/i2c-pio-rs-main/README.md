# I2C PIO

Implements the I2C hal using the RP2040 PIO peripheral.

Refer to the [`rp-hal`](https://github.com/rp-rs/rp-hal) for examples.
