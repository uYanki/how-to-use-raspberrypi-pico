This directory contains reference information on can2040's usage of
the Raspberry Pi rp2040 "Programmable Input/Output block" (PIO).

One may use the can2040 code without needing to build or utilize the
files in this directory.

This information here may be useful for those interested in the
internal behavior of the can2040 implementation.
