# EGL_ON_PICO

EGL3D图形引擎在PICO上运行(EGL 3D Engine on raspberry pi PICO LCD)

EmberGL地址：https://github.com/EmberGL-org/EmberGL

注意：pico-sdk需要解压出来使用

![IMG_20230214_002833](https://user-images.githubusercontent.com/23308519/218516243-ba5d68dc-a589-48fe-b55a-548306194730.jpg)

