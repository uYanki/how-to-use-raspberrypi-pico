
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'template' 
 * Target:  'AC6-DebugInSRAM-printf' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* GorgonMeducer.Performance Counter::Utilities:perf_counter:Core:Library:1.9.11 */
#define __PERF_COUNTER_CFG_USE_SYSTICK_WRAPPER__


#endif /* PRE_INCLUDE_GLOBAL_H */
