This is an unofficial Pulseview windows installer to use the raspberry pi pico on windows.

Github limits filesizes to 25MB but it is 40MB.  You should be able to download this without creating a drobox account.

Revision 2 is now released, and available here.  Since this is a major release, the PICO will need a new UF2 file to match.

https://www.dropbox.com/s/i1guje5kg89yi7a/pulseview-0.5.0-git-7e5c839-installer_rev2.exe?dl=0


It is recommended that you uninstall previous versions first. 

You may need to install this to get msvcr100.dll
https://www.microsoft.com/en-us/download/details.aspx?id=26999![image](https://user-images.githubusercontent.com/99157244/158026832-9f6b139b-6ea1-4aa0-80c2-4fb8def398fa.png)

Other windows related information is here (but note the links to install mscvr100.dll are out of date).
https://sigrok.org/wiki/Windows

Old rev1 is here, but the old UF2 is no longer available (unless you use git pulls to get an older version).

https://www.dropbox.com/s/rnktz830phgl1ag/pulseview-0.5.0-git-7e5c839-installer_rev1.exe?dl=0
