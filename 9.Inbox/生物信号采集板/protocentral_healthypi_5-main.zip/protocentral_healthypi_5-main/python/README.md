# Requirements

* Python 3.7, 3.9 + (Tested on Python 3.10.9)

# Dependencies

pip3 install :

* pyserial
* pylsl
