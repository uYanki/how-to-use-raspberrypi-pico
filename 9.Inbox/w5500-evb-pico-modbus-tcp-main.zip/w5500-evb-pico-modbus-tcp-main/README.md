# w5500-evb-pico-modbus-tcp
Basic Modbus TCP Library for Raspberry Pi Pico
