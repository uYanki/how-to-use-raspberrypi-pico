################################################################################
#
#                            rpi-pico-blink.eww
#
# $Revision: 32 $
#
################################################################################

DESCRIPTION
===========

  These example projects show how to use the IAR Embedded Workbench for ARM
  to develop a code for Raspberry Pi RP2040.


  pico-blink.ewp
  --------------
  Simple program that blinks the on-board LED of Raspberry Pi Pico board.


  pico-boot2.ewp
  --------------
  Second stage boot code. Contains two configurations:

  1) generic_03h

  Configures SSI to translate each APB read into a 03h command
  8 command clocks, 24 address clocks and 32 data clocks
  This enables you to boot from almost any serial flash memory.
  The tradeoff is performance around 3x worse than QSPI XIP

  2) w25q080

  Configures the on-board serial memory to run in Quad I/O continuous
  read XIP mode.
  Supported devices: W25Q080, W25Q16JV, AT25SF081, S25FL132K0

  More information at: https://github.com/raspberrypi/pico-sdk

  The checksum is automatically generated and added by the IAR linker
  to the bootloader image for each configuration.


  Debugger wiring connections
  ---------------------------
  The table below considers the ARM20 connector.

  | ARM20      | RPi Pico   |
  | header     | board pad  |
  | ---------- | ---------- |
  | 1          | 3V3        |
  | 4          | GND        |
  | 7          | SWDIO      |
  | 9          | SWCLK      |

  The table below considers the MIPI10/20 connector.

  | MIPI10/20  | RPi Pico   |
  | header     | board pad  |
  | ---------- | ---------- |
  | 1          | 3V3        |
  | 3          | GND        |
  | 2          | SWDIO      |
  | 4          | SWCLK      |

  More information at: https://developer.arm.com/documentation/ka001776/latest


COMPATIBILITY
=============
  The pico-blink application is compatible with Raspberry Pi Pico board,
  but with minor modifications it can run on any RP2040 board.
  By default, the projects are configured to use I-Jet debug probe.


CONFIGURATIONS
===============

pico-blink
-----------
  Debug:
    This configuration is intended for debugging in QSPI flash memory.

  Release:
    This configuration is intended to produce a QSPI release build that uses
    higher compiler optimizations, and may not be suitable for debugging.

pico-boot2
-----------
  generic_03h:
    Builds a generic second stage bootloader for RP2040. It could be used
    on any RP2040 board.

  w25q080:
    Builds Winbond W25Q080/W25Q16JV specific second stage bootloader
    for RP2040, intended for use with Raspberry Pi Pico board.


GETTING STARTED
===============

  1) Switch to pico-boot2 - w25q080 configuration and build it. This will
     create the second stage bootloader image (boot2.bin).

  2) Switch to pico-blink - Debug configuration and build it. This will build
     the blinking led example application. The second stage bootloader image
     will be linked at 0x10000000.

  NOTE: Alternatively, the "Batch build" functionality could be used to build
  all needed configurations at once. Select Project->Batch build or press F8
  to open the Batch build dialog box.

  3) Download and run the example.
