PicoAWG任意波形发生器RP2040固件。

RP2040 firmware for PicoAWG wave generator.

Tested with MicroPython runtime: rp2-pico-20230426-v1.20.0.uf2

[Hardware](https://oshwhub.com/32478yf4780gf72r49fg4/picoawg)
