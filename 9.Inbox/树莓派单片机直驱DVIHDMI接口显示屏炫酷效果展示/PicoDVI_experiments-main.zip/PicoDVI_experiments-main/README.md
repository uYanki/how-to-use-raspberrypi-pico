# PicoDVI_experiments

Experiments using PicoDVI (mostly on Adafruit DVI RP2040 Feather),

These demos all use [Adafruit's PicoDVI fork](https://github.com/adafruit/PicoDVI/)
that makes the video framebuffer look like a regular
[Adafruit_GFX object](https://github.com/adafruit/Adafruit-GFX-Library/).
(thx @PaintYourDragon!)
This makes drawing to it really easy.

## Demo

https://user-images.githubusercontent.com/274093/230142731-7d3b9510-4b6b-4370-b233-3583915d5471.mp4

[demo on youtube](https://www.youtube.com/watch?v=yEY8iRZ_L4E)



https://user-images.githubusercontent.com/274093/234426197-69f821fb-b2f2-49fd-8908-5667362c9e83.mp4

[demo on youtube](https://www.youtube.com/watch?v=5tgbiDAT5lE)

