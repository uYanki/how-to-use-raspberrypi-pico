# RaspberryPiPicoBlinkW5500
Raspberry pi pico - W5500-EVB-Pico - built-in LED blink
