#ifndef __ETH_H__
#define __ETH_H__

#include <stdint.h>

void eth_init(void);
void eth_main(void);

#endif //__ETH_H__
