Dhrystone for Pi
-

This directory contains the source files & executable for Dhrystone. The executable is compiled to run on the Pi 1/ARMv6 processors. Dhrystone was created by Reinhold P. Weicker, and the executable was
compiled by Roy Longbottom (source: http://www.roylongbottom.org.uk/Raspberry_Pi_Benchmarks.zip).
