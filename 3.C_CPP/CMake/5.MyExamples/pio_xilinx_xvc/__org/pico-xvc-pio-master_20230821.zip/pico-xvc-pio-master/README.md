# PICO-XVC-PIO
A project for rp2040 xvc
Use rndis in tinyusb and use freerots to create usb-related tasks.You can also use socket-related interfaces in this project。

if use the test.uf2,you can download the bit with this pin
PIN | Number
--|--
PIN_SCK |2
PIN_TDI |3
PIN_TDO |4
PIN_TMS |5

For more information, see this website.
https://whycan.com/p_82551.html#p82551
