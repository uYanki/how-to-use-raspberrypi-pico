#include "pico/stdlib.h"
#include "Vtop.h"
#include "io.h"

extern Vtop *top;
extern inputMapping ins[]; 
extern outputMapping outs[];
uint NUM_INPUTS, NUM_OUTPUTS;

