#pragma once

#define FW_VERSION 0x01
