#pragma once

#include <stdint.h>

// enum { ITF_NUM_VENDOR_0, ITF_NUM_CDC_0, ITF_NUM_CDC_0_DATA, ITF_NUM_TOTAL };
enum { ITF_NUM_VENDOR_0, ITF_NUM_TOTAL };
