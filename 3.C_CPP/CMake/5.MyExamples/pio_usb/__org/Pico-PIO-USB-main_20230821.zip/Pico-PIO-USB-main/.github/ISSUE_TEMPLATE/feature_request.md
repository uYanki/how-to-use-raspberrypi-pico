---
name: Feature Request
about: Suggest an idea for this project.
title: '💡[FEATURE] Give a suitable title'
labels: feature-request
assignees: ''

---

<!-- Hey there, thank you for creating an issue! -->


**Describe the feature you want to implement here:**
<!--
Please describe in detail the feature you want to implement to this project.
-->

---