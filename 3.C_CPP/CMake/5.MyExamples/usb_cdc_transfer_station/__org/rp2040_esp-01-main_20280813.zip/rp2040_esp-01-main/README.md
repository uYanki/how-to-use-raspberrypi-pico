# rp2040_esp-01
RPi Pico and ESP-01 project
