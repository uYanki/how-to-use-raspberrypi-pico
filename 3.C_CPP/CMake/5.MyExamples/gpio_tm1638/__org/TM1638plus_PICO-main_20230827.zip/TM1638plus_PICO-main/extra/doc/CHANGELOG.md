# Changelog

* Version 1.0.0 August 2022
	* first release

* Version 1.9.0 October 2022
	* Updating project so it's matches changes made to original Arduino port, V1.9.0.

* Version 2.0.0 April 2023 
	* Updating project so it's matches changes made to original Arduino port, V 2.0.0.
