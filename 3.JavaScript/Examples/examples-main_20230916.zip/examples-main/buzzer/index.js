var pin = 12;
tone(pin, 262); // C4
delay(500);
tone(pin, 294); // D4
delay(500);
tone(pin, 330); // E4
delay(500);
tone(pin, 370); // F4
delay(500);
tone(pin, 392); // G4
delay(500);
tone(pin, 440); // A4
delay(500);
tone(pin, 466); // B4
delay(500);
tone(pin, 523); // C5
delay(500);
noTone(pin);
